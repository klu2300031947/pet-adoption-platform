function Signup() {
  return (
    <div>
      <h2>Signup</h2>
      <form>
        <input type="text" placeholder="Name" required /><br />
        <input type="email" placeholder="Email" required /><br />
        <input type="password" placeholder="Password" required /><br />
        <button type="submit">Signup</button>
      </form>
    </div>
  );
}

export default Signup; // ✅ THIS IS REQUIRED
