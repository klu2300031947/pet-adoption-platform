import { useState } from 'react';
import Login from './components/Login';
import Signup from './components/Signup';
import './App.css'; // Ensure your styles are applied here

function App() {
  const [showLogin, setShowLogin] = useState(true);

  return (
    <div className="app-container">
      <h1>🐾 Pet Adoption Platform</h1>

      {/* Toggle Buttons */}
      <div className="toggle-buttons">
        <button
          className={showLogin ? 'active' : ''}
          onClick={() => setShowLogin(true)}
        >
          Login
        </button>
        <button
          className={!showLogin ? 'active' : ''}
          onClick={() => setShowLogin(false)}
        >
          Signup
        </button>
      </div>

      <div style={{ marginTop: '20px' }}>
        {showLogin ? <Login /> : <Signup />}
      </div>
    </div>
  );
}

export default App;
